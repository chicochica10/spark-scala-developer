package com.gft.sparktraining

/**
 * Created by chicochica10 on 6/06/15.
 */

import org.apache.spark._
import org.apache.spark.mllib.linalg.Vectors

object MovieLensALS {
  def main (args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName ("MovieLensALS").
      set("spark.executor.memory", "1g")
    val sc = new SparkContext (conf)

    //load personal ratings
    val myRatings = loadRatings (args(0))
    val myRatingsRDD = sc.parallelize(myRatings)

    //load ratings and movie titles
    val movieLensHomeDir = args (1)
    // ratings is an RDD of (last digit of timestamp, (userId, movieId, rating))
    val ratings = sc.textFile(movieLensHomeDir + "ratings.dat").map(parseRating)

    // movies is an RDD of (movieId, movieTitle)
    val movies = sc.textFile(movieLensHomeDir + "movies.dat").map(parseMovie)
    //used later in recomendation
    val moviesMap = movies.collect.toMap

    //your code here



    //Shut down the SparkContext.
    sc.stop()


  }

  //load ratings from file
  def loadRatings (ratingsFile: String) = ???

  //Parses a rating record in MovieLens format userId::movieId::rating::timestamp .
  def parseRating (line: String) = ???

  //Parses a movie record in MovieLens format movieId::movieTitle .
  def parseMovie (line: String) = ???


  def computeRmse(model: MatrixFactorizationModel, data: RDD[Rating], n: Long): Double = {
    val predictions: RDD[Rating] = model.predict(data.map(x => (x.user, x.product)))
    val predictionsAndRatings = predictions.map(x => ((x.user, x.product), x.rating))
      .join(data.map(x => ((x.user, x.product), x.rating)))
      .values
    math.sqrt(predictionsAndRatings.map(x => (x._1 - x._2) * (x._1 - x._2)).reduce(_ + _) / n)
  }

}



